# Zarya add-on contracts

Version 0.1.0 contains framework-independent extension contracts shared by CMS
Zarya and independently built add-ons. Node 26.7.0 / npm 11.19.0 are required.

- addons: definition/configuration metadata, site connection state enum,
  operation access classes, captured connection permits, the application access
  policy port and the typed browser administration host.
- business-error: shared typed errors/codes for boundary translation.
- validation: existing neutral business value checks.
- cursor-page: neutral paged result shapes.
- snapshot-entity: defensive business state snapshots.

The SDK does not contain NestJS providers, Mongoose types, repositories, runtime
service locators or permission grants. Implementations belong to their owning
application/adapters and are bound by trusted composition. The host authorizes
actors/sites independently and enforces captured add-on permits at write commit.

Build with the CMS workspace command `npm run build:contracts`. Package with
`npm pack --workspace @zarya/addon-contracts`. Independent add-on development uses
the fixed-version SDK tarball with committed lockfile integrity; production
consumers never import another repository's source checkout.

Version 0.2.0 adds optional bilingual adminMenu metadata and a host boundary for
site timeZone, route/query history, private configuration saving, dirty/busy state
and the shared scroll-shadow action. UI packages use CMS theme classes instead of
copying CSS or importing host source. The reserved adminMenuLabels configuration
field contains only localized presentation overrides; it is not authorization.
